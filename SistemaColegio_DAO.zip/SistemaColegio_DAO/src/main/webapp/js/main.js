function confirmarEliminacionAlumno() {
    return window.confirm("¿Estás seguro de Eliminar este Alumno?")
}

function confirmarEliminacionCurso() {
	/*let cantidadAlumnos = document.getElementsByName('cantidadAlumnos')[0].value;
    if(cantidadAlumnos > 0) {
       alert("¡No se puede Borrar Curso, porque hay alumnos inscriptos!.");
       return false;
   }*/
    return window.confirm("¿Estás seguro de Eliminar este Curso?")
}